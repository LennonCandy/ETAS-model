


setwd("~/..../")# set up work path
source(file = "model/Two_alpha_model_{zhang}.R")    #load the forcecast model function from the R code

#myargs = commandArgs(trailingOnly=TRUE)
#datetime<-paste0(myargs[1],"T00:00:00")    #"2009-04-07T00:00:00"

catalog<-read.table("input/sc_1981_2019_1d_3d_gc_soda.txt",sep = "",stringsAsFactors = F,fill=T)[,1:11]  # read catalog
colnames(catalog)<-c("YR","MO", "DAY","HR","MN","SEC","ID","Lat","Lon","DEPTH","MAG")
M0<-3
catalogx<-catalog[catalog$MAG>=M0,]       # Choose Magnitude with threshold M0


datetime<-"1992-06-28 11:58:00"  ## ֮??????
fT=1                                 # set the forcecast time length as 1 day
seedi=1                           # random seed

startT<-strptime(datetime,"%Y-%m-%d %H:%M:%S",tz="UTC") # set the beginning time of forcecast 
forecast_catalog<-FORECAST(startT=startT,fT=fT,catalog3=catalogx,seedi=seedi)

#============save forecast catlog as csv file==================
#/usr/src/tests/
filename1<-paste0("examples/model_foo-",substr(datetime,1,10),"seed_",seedi,".csv")
write.table(c("lon, lat, M, time_string, depth, catalog_id, event_id"),file = filename1, sep=",", row.names = F, col.names=FALSE)
write.table(forecast_catalog,file = filename1, sep=",", row.names = F, col.names=FALSE,na = "",quote = FALSE,append = T)


#forecast_catalog


#plot(catalogx$Lon[4261:(4261+364)],catalogx$Lat[4261:(4261+364)],col=2,cex=0.1)
#plot(forecast_catalog$lon,forecast_catalog$lat,col=2,cex=0.1)




