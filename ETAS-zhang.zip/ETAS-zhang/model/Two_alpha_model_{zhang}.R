
#=================== main function to forecast =========================
FORECAST<-function(startT,fT,catalog3,seedi)            
{
  
  dat1<-paste0(catalog3$YR,"-",catalog3$MO,"-",catalog3$DAY)
  dat2<-paste0(catalog3$HR,":",catalog3$MN,":",catalog3$SEC)
  Time<-strptime(paste(dat1,dat2),"%Y-%m-%d %H:%M:%S",tz="UTC")
  DTime<-sapply(1:length(Time),function(x){as.numeric(difftime(Time[x],Time[1],units = "days"))})     # get time differences with the first events in the catalog
  
  
  DTime0<-as.numeric(difftime(startT,Time[1],units = "days"))      # time difference bewteen the beginning time to forecast and the first events in the catalog
  history_data<-data.frame(time=DTime[DTime<DTime0],mag=catalog3$MAG[DTime<DTime0],x=catalog3$Lon[DTime<DTime0],y=catalog3$Lat[DTime<DTime0]) # get history data before the beginning time to forecast  
  
  lmax<-1000  #length(history_data$time)
  
  mu=0.2931507
  c=0.012
  alpha<-2.29
  p<-1.13
  A=0.087*(p-1)/c
  
  Q<-1.53
  D<-sqrt(0.072)
  gamma<-1.87/2
  
  
  
  params<- c(mu,A,alpha,c,p,Q,D,gamma)    #Parameters for ETAS model
  
  sim_data<-ETAS_T(data=history_data, params=params, sequence.length=DTime0+fT, seed=seedi, bvalue=0.99, M0=M0)  #forecast events in time 
  
  simfT_index<-which((sim_data$times>=DTime0)&(sim_data$times<(DTime0+fT))) # find event index within the forecast day
  
  if(length(sim_data$times[simfT_index])>0)
  {
    italy_bg_density<-read.csv("input/Input_Background_Density_cl.csv")        #load the backgound density in space
    # forecast events in space
    data.xy<-aftershock.xy(history_data$x,history_data$y,sim_data$magnitudes-M0,sim_data$times,lmax,italy_bg_density$lon,italy_bg_density$lat,italy_bg_density$prb, params, seed=seedi)
    sim_data[["lon"]]<-data.xy$x
    sim_data[["lat"]]<-data.xy$y
    
    op <- options(digits.secs = 2)
    # obtain the new events 
    New_time<-as.POSIXct(sim_data$times[simfT_index]*86400, origin = Time[1], tz = "UTC") 
    New_magnitudes<-round(sim_data$magnitudes[simfT_index],digits = 1)
    New_lon<-round(sim_data$lon[simfT_index],digits = 3)
    New_lat<-round(sim_data$lat[simfT_index],digits = 3)
    
    # define forecast catalog as data frame  
    forecast_catalog<-data.frame(lon=New_lon,lat=New_lat,M=New_magnitudes,time_string=New_time,
                                 depth=rep(NA,length(New_time)),catalog_id=rep(NA,length(New_time)),event_id=rep(NA,length(New_time)))
    
    forecast_catalog$lon[forecast_catalog$lon>180]<-forecast_catalog$lon[forecast_catalog$lon>180]-360
    
    
  }
  if(length(sim_data$times[simfT_index])==0) # No event in the forecast day
  {
    
    forecast_catalog<-data.frame(lon=NA,lat=NA,M=NA,time_string=NA,depth=NA,catalog_id=NA,event_id=NA)
  }
  
  return(forecast_catalog)
}


#=================== simulate function of earthquake time =========================

ETAS_T<-function(data, params, sequence.length, seed, bvalue, M0) 
{
  
  set.seed(seed)
  
  if(is.null(data))
  {
    data.time<-Inf 
    data.mag<-0
    
  }
  
  data.mag<-data$mag-M0
  data.time<-data$time
  
  ti<-max(data.time)
  Rmax <- conditional.intensity(data.mag=data.mag,
                                data.time=data.time, eval.time=ti, params=params)
  
  
  repeat
  {
    
    if(Rmax > 0) tau <- rexp(1, rate = Rmax)
    else tau <- Inf
    ti <- ti + tau
    if (ti > sequence.length) break
    #if(length(aftershock.times)>)
    rate <- conditional.intensity(data.mag=data.mag, data.time=data.time, eval.time=ti, params=params)
    if (runif(1, 0, 1) <= rate/Rmax)
    {
      # select a magnitude
      
      #new.mag <- rexp(1, bvalue * log(10))
      
      new.mag <- F_GM(1,M0,Max=7.5,bvalue)
      
      #print(new.mag)
      
      data.time <- c(data.time, ti)
      data.mag <- c(data.mag, new.mag-M0)
      
      ti<-max(data.time)
      Rmax <- conditional.intensity(data.mag=data.mag,
                                    data.time=data.time, eval.time=ti, params=params)
    }else{
      Rmax <- rate
    }
  }
  
  
  final.events <- list(times=data.time,
                       magnitudes=data.mag+M0)
  return(final.events)
  
}

#===================Conditional intensity funtion==============================

conditional.intensity <- function(data.mag, data.time, eval.time, params)
{
  mu <- params[1]
  A <- params[2]
  alpha <- params[3]
  CC <- params[4]
  P <- params[5] 

  
  if (length(data.time) > 0)
  {
      triggering.ci <- A*sum(exp(alpha * data.mag) *
                               (1 + (eval.time - data.time)/CC)^(-P))
  
  }else triggering.ci <- 0
  ci <- mu + triggering.ci
  return(ci)
}


#=================== simulate function of earthquake location=========================

aftershock.xy<-function(x0,y0,data.mag,data.time,lmax,xx,yy,bg,params,seed)
{ 
  
  set.seed(seed)
  data.x<-x0
  data.y<-y0
  
  mu <- params[1]
  A <- params[2]
  alpha <- params[3] 
  CC <- params[4]
  P <- params[5] 
  Q<-params[6]
  D<-params[7]
  gamma<-params[8]

  
  for(t0 in (lmax+1):(length(data.mag)))
  {
    
    triggering.ci0 <- A*exp(alpha * data.mag[(t0-lmax):(t0-1)]) *
      (1 + (data.time[t0] - data.time[(t0-lmax):(t0-1)])/CC)^(-P)           #Truncation with a max length lmax
    
    triggering.ci<-c(triggering.ci0,mu)
    
    index<-sample(1:length(triggering.ci),1,replace=T,prob = triggering.ci)
    
    if(index<(lmax+1))    # if it is an aftershock  
    {
      
      sigma<-D*exp(gamma*data.mag[t0])
      index2<-t0-lmax+index-1
      R<-sigma*sqrt(runif(1)^(1/(1-Q))-1)
      theta<-runif(1,0,2*pi)
      #rx<-R*cos(theta)+data.x[index2]
      #ry<-R*sin(theta)+data.y[index2]
      rxy0<-discovdeg(data.x[index2],data.y[index2],theta,R)
      rx<-rxy0[1]
      ry<-rxy0[2]
      
    }else{   #if it is a background event 
      index3<-sample(1:length(bg),1,replace = T,prob = bg)
      rx<-xx[index3]
      ry<-yy[index3]
    }
    
    data.x<-c(data.x,rx)
    data.y<-c(data.y,ry)
  }
  
  return(list(x=data.x,y=data.y))
}

#===================simulate function of earthquake magnitudes================================
#M0<-3
#Max<-7.5
#bvalue<-0.99

F_GM<-function(nx,M0,Max,bvalue)
{
  Mx<-seq(M0,Max,0.01)
  
  Beta0<-bvalue*log(10)
  PMx<-(Beta0*exp(-Beta0*Mx))/(exp(-Beta0*M0)-exp(-Beta0*Max))
  PbMx<-PMx/sum(PMx)
  
  mg<-sample(Mx,nx,replace = T, prob = PbMx)
  
  return(mg)
}


discovdeg<-function(lonx,latx,brng,d)
{
  R<-6378.1 #Radius of the Earth
  lat1 = (latx*pi)/180  #Current lat point converted to radians
  lon1 = (lonx*pi)/180 #Current long point converted to radians
  
  lat2 = asin(sin(lat1)*cos(d/R) + cos(lat1)*sin(d/R)*cos(brng))
  
  lon2 = lon1 + atan2(sin(brng)*sin(d/R)*cos(lat1),cos(d/R)-sin(lat1)*sin(lat2))
  
  lat2 = (lat2*180)/pi
  lon2 = ((lon2%%(2*pi))*180)/pi
  return(c(lon2,lat2))
}




# 
# catalog<-read.table("input/sc_1981_2019_1d_3d_gc_soda.txt",sep = "",stringsAsFactors = F,fill=T)[,1:11]  # read catalog
# colnames(catalog)<-c("YR","MO", "DAY","HR","MN","SEC","ID","Lat","Lon","DEPTH","MAG")
# M0<-3
# catalogx<-catalog[catalog$MAG>=M0,]       # Choose Magnitude with threshold M0
# 
# 
# datetime<-"1999-10-16 09:46:44.00"  ## ֮??????
# fT=30                                 # set the forecast time length as 1 day
# startT<-strptime(datetime,"%Y-%m-%d %H:%M:%S",tz="UTC") # set the beginning time of forecast 
# 
# 
# cum_x<-matrix(nrow = 1000,ncol = 30)
# 
# for(i in 1:1000)
# {
# seedi=i                           # random seed
# forecast_catalog<-FORECAST(startT=startT,fT=fT,catalog3=catalogx,seedi=seedi)
# 
# DTime_x<-sapply(1:length(forecast_catalog$M),function(x){as.numeric(difftime(forecast_catalog$time_string[x],startT,units = "days"))})     # get time differences with the first events in the catalog
# hist_x<-hist(DTime_x,breaks = seq(0,30,1),plot = "F")
# cum_x[i,]<-cumsum(hist_x$counts)
# print(i)
# }
# 
# 
# cum_xm<-colMeans(cum_x)
# plot(c(0:29),cum_xm)
# 
# 
# dat1<-paste0(catalogx$YR,"-",catalogx$MO,"-",catalogx$DAY)
# dat2<-paste0(catalogx$HR,":",catalogx$MN,":",catalogx$SEC)
# Time<-strptime(paste(dat1,dat2),"%Y-%m-%d %H:%M:%S",tz="UTC")
# DTime_r<-sapply(7666:length(Time),function(x){as.numeric(difftime(Time[x],startT,units = "days"))})
# 
# 
# hist_r<-hist(DTime_r[2:499],breaks = seq(0,30,1),plot = "F")
# cum_r<-cumsum(hist_r$counts)
# 
# 
# cum_xm<-colMeans(cum_x)
# plot(cum_xm,ylim = c(100,1500))
# points(cum_r,col=2)
# 
